mex CFLAGS="\$CFLAGS -Wall -m32  -ftree-vectorizer-verbose=5 -msse -msse2 -msse3 -march=native -mtune=native --std=c99 -fPIC -ffast-math -std=c99" -largeArrayDims  mexLDKLTrain.cpp ../src/Utils.cpp ../src/LDKLSolver.cpp
mex CFLAGS="\$CFLAGS -Wall -m32  -ftree-vectorizer-verbose=5 -msse -msse2 -msse3 -march=native -mtune=native --std=c99 -fPIC -ffast-math  -m32 -std=c99" -largeArrayDims  mexLDKLPredict.cpp ../src/Utils.cpp ../src/LDKLEvaluate.cpp


