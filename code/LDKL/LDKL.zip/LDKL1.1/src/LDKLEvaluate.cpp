//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#include<math.h>
#include "../include/Utils.h"
#include "../include/LDKLModel.h"
int LDKLEvaluate(struct LDKLModel &model){
	DATA X = model.X;
	LABEL Y = model.Y;
	MyFloat *Score = model.Score;
	MyFloat *W = model.W;
	MyFloat *ThetaPrime = model.ThetaPrime;
	MyFloat *Theta = model.Theta;
	MyFloat Sigma = model.Sigma;
	int M = model.M;
	int D = model.D;
	int N = model.N;
	int Correct = 0;
	for(int n = 0 ; n < N; n++){
		int curr = 0;
		Score[n] = 0;
		while(curr < M-1){
			Score[n] += tanh(Sigma*_dot(X[n],ThetaPrime+curr*D,D)) * _dot(X[n],W+curr*D,D);
			MyFloat t = _dot(X[n],Theta+curr*D,D);
			curr = (t>0) ? 2*curr+1 : 2*curr+2;
		}
		Score[n] += tanh(Sigma*_dot(X[n],ThetaPrime+curr*D,D)) * _dot(X[n],W+curr*D,D);
		if(Y[n]*Score[n]>0)
			Correct++;
	}
	return Correct;
}