//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#ifndef _LDKLSOLVER_H_
#define _LDKLSOLVER_H_
void PathWeight(INSTANCE X, MyFloat* pathwt,const MyFloat *Theta, const MyFloat rbfgamma, const int L, const int D);
void GradTheta(INSTANCE X, MyFloat *grad, const MyFloat* pathwt, const MyFloat* localwt, const MyFloat *W,const MyFloat *Theta,const int M, const int D,const MyFloat rbfgamma);
MyFloat ComputePrimalObj(DATA X, LABEL y, const MyFloat *W, const MyFloat *ThetaPrime, const MyFloat *Theta, const MyFloat lW, const MyFloat lThetaPrime, const MyFloat lTheta, const MyFloat Sigma, const int M, const int D, const int N,const MyFloat rbfgamma);
void LDKLTrain(DATA Data, LABEL Y, MyFloat *W, MyFloat *Theta, MyFloat *ThetaPrime, const int M, const MyFloat lW, const MyFloat lTheta, const MyFloat lThetaPrime,const MyFloat Sigma,const int MaxIter,const int N, const int D);
#endif