//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#ifndef _UTILS_H_
#define _UTILS_H_
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <xmmintrin.h>
#define MyFloat float
#define SPARSE 0 // 0 if using dense data format. 1 if using libsvm data format
#define SSE 1    // 1 to enable SSE Acceleration support.
using namespace std;

#if SPARSE
	struct _instance{
		int count;
		MyFloat* val;
		int* idx;
	};
	
	struct _idxval{
		int idx;
		MyFloat val;
	};
	typedef struct _idxval Node;
	

	typedef struct _instance INSTANCE;
	typedef INSTANCE* DATA;
#else
	typedef MyFloat Node;
	typedef Node* INSTANCE;
	typedef INSTANCE* DATA;
#endif

typedef MyFloat* LABEL;

// Compute base 2 logirithm

unsigned int log2( unsigned int x );

// Compute Dot Product of Vectors

#if SPARSE
#if SSE
	inline MyFloat _dot(INSTANCE X, MyFloat* V, int D) {
		int *idx = X.idx;
		MyFloat *val = X.val;
		const int * idxLim = idx + X.count; // upper bound for idx
        __m128 res = _mm_setzero_ps(); // temporary result register
        for (; idx + 4 <= idxLim; idx += 4, val += 4)
        {
            __m128 x = _mm_loadu_ps(val);
            __m128 y = _mm_setr_ps(V[idx[0]], V[idx[1]], V[idx[2]], V[idx[3]]);
            res = _mm_add_ps(res, _mm_mul_ps(x, y));
        }
        MyFloat temp[4];
		_mm_storeu_ps(temp,res);
        MyFloat sum = temp[0] + temp[1] + temp[2] + temp[3];
        for (; idx < idxLim; ++idx, ++val) // add the remaining last elements
            sum += (*val) * V[*idx];
        return sum;
	}
#else
	inline MyFloat _dot(INSTANCE X, MyFloat* V, int D) {
		MyFloat val = 0.0;
		int cur = 0;
		for(int i = 0 ; i < X.count ; i++){
			val += X.val[i] * V[X.idx[i]];
		}
		return val;
	}
#endif
#else
#if SSE
	inline MyFloat _dot(INSTANCE X, MyFloat* V, int count) {
		__m128 res = _mm_setzero_ps(); // temporary result register
		int i = 0;
        for (; i + 4 <= count; i += 4, X += 4, V += 4)
        {
            __m128 x = _mm_loadu_ps(X);
            __m128 y = _mm_loadu_ps(V);
            res = _mm_add_ps(res, _mm_mul_ps(x, y));
        }
        MyFloat temp[4];
		_mm_storeu_ps(temp,res);
        MyFloat sum = temp[0] + temp[1] + temp[2] + temp[3];
        for (; i < count; ++i, ++V, ++X) // add the remaining last elements
            sum += (*X) * (*V);
        return sum;
	}
#else
	inline MyFloat _dot(INSTANCE X, MyFloat* V, int count) {
		MyFloat result = 0;
		for(int i = 0 ; i < count ; i++)
			result += X[i]*V[i];
		return result;
	}
#endif
#endif

// Implements v = v + scale * X 

#if SPARSE
#if SSE
	inline void _add(INSTANCE X, MyFloat* V, int D, MyFloat scale){
		const int count = X.count;
		int* idx = X.idx;
		MyFloat* val = X.val;
		const int * idxLim = idx + count; // upper bound for pi
		__m128 temp = _mm_set1_ps(scale); // register containing value of scale
		MyFloat result[4];
		for (; idx + 4 <= idxLim; idx += 4, val += 4)
		{
			__m128 x = _mm_loadu_ps(val);
			__m128 v = _mm_setr_ps(V[idx[0]], V[idx[1]], V[idx[2]], V[idx[3]]);
			_mm_storeu_ps(result, _mm_add_ps(v, _mm_mul_ps(x, temp)));
			V[idx[0]] = result[0];
			V[idx[1]] = result[1];
			V[idx[2]] = result[2];
			V[idx[3]] = result[3];
		}
		for (; idx < idxLim; ++idx, ++val) // add the remaining last elements
			V[*idx] += (*val) * scale;
	}
#else
	inline void _add(INSTANCE X, MyFloat* V, int D, MyFloat scale){
		for(int i = 0 ; i < X.count ; i++){
			V[X.idx[i]] += scale * X.val[i];
		}
	}
#endif
#else
#if SSE
	inline void _add(INSTANCE X, MyFloat* V, int count, MyFloat scale){
		int i = 0;
		__m128 temp = _mm_set1_ps(scale);
		for(; i + 4 <= count; i += 4, X += 4, V += 4)
		{
			__m128 x = _mm_loadu_ps(X);
			__m128 v = _mm_loadu_ps(V);
			__m128 result  = _mm_add_ps(v , _mm_mul_ps(x , temp));
			_mm_storeu_ps(V,result);
		}
		for(; i < count ; ++i, ++X, ++V)//Compute remaining last elements
			(*V) += scale * (*X);
	}
#else
	inline void _add(INSTANCE X, MyFloat* V, int count, MyFloat scale){
		for(int i = 0 ; i < count ; i++){
			V[i] += X[i]*scale;
		}
	}

#endif
#endif

// Scale a vector by a scaler

#if SSE
	inline void _scale(MyFloat* V, const MyFloat scale, int count){
		__m128 _scale = _mm_set1_ps(scale);
		int i = 0;
		for (; i + 4 <= count; i += 4, V += 4)
        {
            __m128 x = _mm_loadu_ps(V);
            __m128 result = _mm_mul_ps(x, _scale);
			_mm_storeu_ps(V , result);
        }
		for(; i < count ; ++i, ++V)//Process Remaining elements
			(*V) *= scale;
	}
#else
inline void _scale(MyFloat* V, const MyFloat scale, int count){
	for(int i = 0 ; i < count ; i++)
		V[i] *= scale; 
}
#endif

// Compute L2 norm of Vector

MyFloat dnrm2_(const MyFloat *v, int n);

// Multiply Vector by a Scaler

void dscal_(MyFloat *v, const MyFloat s,  int n);

// Average of Numbers

MyFloat avg(MyFloat *Data, int N);
double avg(double *Data, int N);

// Load Dataset

void ReadData(char* FileName, DATA &X, LABEL &y,int &D, int &N);
#endif