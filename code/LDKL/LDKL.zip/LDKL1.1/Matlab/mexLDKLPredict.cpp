//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <t-sujain@microsoft.com> and Manik Varma <manik@microsoft.com>//
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#include <iostream>
#include <math.h>
#include "mex.h"
#include "string.h"
#include "../include/Utils.h"
#include "../include/Timer.h"
#include "../include/LDKLModel.h"
#include "../include/LDKLEvaluate.h"
#define IS_2D_SPARSE(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P)==2 && mxIsSparse(P))
#define IS_2D_FULL(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P)==2 && !mxIsSparse(P))
#define IS_REAL_SCALAR(P) (IS_REAL_2D_FULL_DOUBLE(P) && mxGetNumberOfElements(P)==1)

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    const mxArray *mxX = prhs[0];
	const mxArray *mxY = prhs[1];
    const mxArray *mxTheta = prhs[2];
    const mxArray *mxW = prhs[3];
    const mxArray *mxThetaPrime = prhs[4];
    const mxArray *mxSigma = prhs[5];
	float *y = (float*)mxGetPr(mxY);
    float *theta = (float*)mxGetPr(mxTheta);
    float *w = (float*)mxGetPr(mxW);
    float *thetaPrime = (float*)mxGetPr(mxThetaPrime);
    const int D = (const int)mxGetM(mxX);
    const int N = (const int)mxGetN(mxX);
    const int M = (const int)(mxGetN(mxTheta) + 1);
    double sigma = (double)mxGetScalar(mxSigma);
    mxArray *mxTime = mxCreateNumericMatrix(1, 1, mxDOUBLE_CLASS, mxREAL);
    double *tPtr = (double*)mxGetPr(mxTime);
	struct LDKLModel model;
	mxArray *mxCorrect = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	int *CorrectPtr = (int*)mxGetPr(mxCorrect);
	mxArray *mxScore = mxCreateNumericMatrix(N, 1, mxSINGLE_CLASS, mxREAL);
	model.Score = (MyFloat*)mxGetPr(mxScore);
	DATA X = new INSTANCE[N];
#if SPARSE
	if(IS_2D_FULL(mxX))
		mexErrMsgTxt("Compiled with SPARSE = 1 in include\\Utils.h but the input data is dense.");
	double* data = NULL;
	mwIndex *ir_data = NULL, *jc_data = NULL;
	int low,high;
	data = mxGetPr(mxX);
    ir_data = mxGetIr(mxX);
    jc_data = mxGetJc(mxX);
	for(int i = 0 ; i < N ; i++){
		low = (int)jc_data[i], high = (int)jc_data[i+1];
		X[i].count = high - low;
		X[i].idx = new int[X[i].count];
		X[i].val = new MyFloat[X[i].count];
		int j = 0;
		for(int k = low ; k < high ; k++){
			X[i].idx[j] = (int)ir_data[k];// Index is 0 based
			X[i].val[j] = (MyFloat)data[k];
			j++;
		}
	}
#else
	if(IS_2D_SPARSE(mxX))
		mexErrMsgTxt("Compiled with SPARSE = 0 in include\\Utils.h but the input data is sparse.");
	float *x = (float*)mxGetPr(mxX);
	for(int i = 0 ; i < N ; i++){
		X[i] = new MyFloat[D];
		for(int j = 0 ; j < D ; j++)
			X[i][j] = x[i*D+j];
	}
#endif
	model.M = M;
	model.N = N;
	model.D = D;
	model.W = w;
	model.Theta = theta;
	model.ThetaPrime = thetaPrime;
	model.Sigma = sigma;
	model.X = X;
	model.Y = y;
    Timer tm;
    tm.StartTimer();
	CorrectPtr[0] = LDKLEvaluate(model);
	tm.StopTimer();
	tPtr[0] = tm.ElapsedTime();
    plhs[0] = mxCorrect;
    plhs[1] = mxTime;
	plhs[2] = mxScore;
#if SPARSE
	for(int i = 0 ; i < N ; i++){
		delete[] X[i].idx;
		delete[] X[i].val;
	}
#else
	for(int i = 0 ; i < N ; i++)
		delete[] X[i];
#endif
	delete[] X;
}