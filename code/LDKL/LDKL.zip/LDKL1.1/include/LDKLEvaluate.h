//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
//////////////////////////////////////////////////////////////////////////////
#ifndef _LDKLEVALUATE_H_
#define _LDKLEVALUATE_H_
struct InputData{
	char DataFile[1024];
	char ModelFile[1024];
	char ResultFile[1024];
	char OutputFile[1024];
	int NModel;
	MyFloat *TestAcc;
	double *TestTime;
};
int LDKLEvaluate(struct LDKLModel &model);
#endif