//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <t-sujain@microsoft.com> and Manik Varma <manik@microsoft.com>//
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#include "string.h"
#include "mex.h"
#include "../include/Utils.h"
#include "../include/Timer.h"
#include "../include/LDKLSolver.h"
#define IS_2D_SPARSE(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P)==2 && mxIsSparse(P))
#define IS_2D_FULL(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P)==2 && !mxIsSparse(P))
#define IS_REAL_SCALAR(P) (IS_REAL_2D_FULL_DOUBLE(P) && mxGetNumberOfElements(P)==1)

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) 
{
  // Get Input Data Pointers
  
  srand(1);  
  const mxArray *mxX = prhs[0];
  const mxArray *mxY = prhs[1];
  const mxArray *mxTheta = prhs[2];
  const mxArray *mxW = prhs[3];
  const mxArray *mxThetaPrime = prhs[4];
  const mxArray *mxLambdaW = prhs[5];
  const mxArray *mxLambdaTheta = prhs[6];
  const mxArray *mxLambdaThetaPrime = prhs[7];
  const mxArray *mxSigma = prhs[8];
  const mxArray *mxMaxIter = prhs[9];
  
  // Get Input Data
  
  const float lambdaW = (const float)mxGetScalar(mxLambdaW);	
  const float lambdaTheta = (const float)mxGetScalar(mxLambdaTheta);
  const float lambdaThetaPrime = (const float)mxGetScalar(mxLambdaThetaPrime);
  const float Sigma = (const float)mxGetScalar(mxSigma);	
  const int MaxIter = (const int)mxGetScalar(mxMaxIter);
  float *y = (float*)mxGetPr(mxY);
  const float *theta = (const float*)mxGetPr(mxTheta);
  const float *W = (const float*)mxGetPr(mxW);
  const float *thetaPrime = (const float*)mxGetPr(mxThetaPrime);

  const int D = (const int)mxGetM(mxX);
  const int N = (const int)mxGetN(mxX);
  const int M = (const int)mxGetN(mxTheta)+1;
  const int L = 2*M-1;
  
  Timer tm;
  
  plhs[0] = mxCreateNumericMatrix(D, L, mxSINGLE_CLASS, mxREAL);
  plhs[1] = mxCreateNumericMatrix(D, M-1, mxSINGLE_CLASS, mxREAL);			
  plhs[2] = mxCreateNumericMatrix(D, L, mxSINGLE_CLASS, mxREAL);			
  plhs[3] = mxCreateNumericMatrix(1, 1, mxDOUBLE_CLASS, mxREAL);

  float *wPtr = (float*)mxGetPr(plhs[0]);
  float *thetaPtr = (float*)mxGetPr(plhs[1]);
  float *thetaPrimePtr = (float*)mxGetPr(plhs[2]);
  double *tPtr = (double*)mxGetPr(plhs[3]);
  
  memcpy(wPtr, W, L*D*sizeof(float));
  memcpy(thetaPrimePtr, thetaPrime, L*D*sizeof(float));
  memcpy(thetaPtr, theta, (M-1)*D*sizeof(float));
  DATA X = new INSTANCE[N];
#if SPARSE
	if(IS_2D_FULL(mxX))
		mexErrMsgTxt("Compiled with SPARSE = 1 in include\\Utils.h but the input data is dense.");
	double* data = NULL;
	mwIndex *ir_data = NULL, *jc_data = NULL;
	int low,high;
	data = mxGetPr(mxX);
    ir_data = mxGetIr(mxX);
    jc_data = mxGetJc(mxX);
	for(int i = 0 ; i < N ; i++){
		low = (int)jc_data[i], high = (int)jc_data[i+1];
		X[i].count = high - low;
		X[i].idx = new int[X[i].count];
		X[i].val = new MyFloat[X[i].count];
		int j = 0;
		for(int k = low ; k < high ; k++){
			X[i].idx[j] = (int)ir_data[k];// Index is 0 based
			X[i].val[j] = (MyFloat)data[k];
			j++;
		}
	}
#else
	if(IS_2D_SPARSE(mxX))
		mexErrMsgTxt("Compiled with SPARSE = 0 in include\\Utils.h but the input data is sparse.");
	const float *x = (const float*)mxGetPr(mxX);
	for(int i = 0 ; i < N ; i++){
		X[i] = new MyFloat[D];
		for(int j = 0 ; j < D ; j++)
			X[i][j] = x[i*D+j];
	}
#endif
  
  tm.StartTimer(); 
  LDKLTrain(X, y, wPtr, thetaPtr, thetaPrimePtr, M, lambdaW, lambdaTheta, lambdaThetaPrime, Sigma, MaxIter, N, D);
  tm.StopTimer();
  
  tPtr[0] = tm.ElapsedTime();
 #if SPARSE
	for(int i = 0 ; i < N ; i++){
		delete[] X[i].idx;
		delete[] X[i].val;
	}
#else
	for(int i = 0 ; i < N ; i++)
		delete[] X[i];
#endif
	delete[] X;
}
