params = {};

params.num_learners = 1;
params.num_clusters = 1;
params.num_threads = 32;
params.SVP_neigh = 250;
params.out_Dim = 100;
params.w_thresh = 0.01;
params.sp_thresh = 0.01;
params.cost = 0.2;
params.NNtest = 25;
params.normalize = 1;
params.fname = 'SLEEC';