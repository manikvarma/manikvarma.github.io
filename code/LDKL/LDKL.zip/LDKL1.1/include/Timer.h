//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#define WINDOWS 1 //Change it to 0 for linux system 
#if WINDOWS
//High Resolution Windows Timer
#include <windows.h> 
#include<time.h>
class Timer{
	LARGE_INTEGER Start;
	LARGE_INTEGER Stop;
public:
	void StartTimer(void){
		QueryPerformanceCounter(&this->Start) ; 
	}
	void StopTimer(void){
		QueryPerformanceCounter(&this->Stop) ; 
	}
	double LIToSecs( LARGE_INTEGER * L) { 
		LARGE_INTEGER frequency;
		QueryPerformanceFrequency( &frequency ) ; 
		return ((double)L->QuadPart /(double)frequency.QuadPart * 1000) ;
	} 
	double ElapsedTime( void) { 
		LARGE_INTEGER time;
		time.QuadPart = this->Stop.QuadPart - this->Start.QuadPart; 
		return LIToSecs( &time) ; 
	}

};
#else 
//High Resolution Linux Timer
#include <sys/time.h>
class Timer {
	timeval timer[2];
public:
	timeval StartTimer(void) {
		gettimeofday(&this->timer[0], NULL);
		return this->timer[0];
	}
	timeval StopTimer(void) {
		gettimeofday(&this->timer[1], NULL);
		return this->timer[1];
	}
	double ElapsedTime(void) const {
		double secs(this->timer[1].tv_sec - this->timer[0].tv_sec);
		double usecs(this->timer[1].tv_usec - this->timer[0].tv_usec);
		if(usecs < 0) {
			--secs;
			usecs += 1000000;
		}
		return (secs * 1000 + usecs / 1000.0);
	}
};
#endif
