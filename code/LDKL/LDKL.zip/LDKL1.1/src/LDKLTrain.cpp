//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#include<stdio.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>
#include "string.h"
#include"../include/Utils.h"
#include"../include/Timer.h"
#include"../include/LDKLSolver.h"
#include"../include/LDKLModel.h"

using namespace std;

void ParseInput(int argc, char** argv, struct LDKLModel &prob);

void exit_with_help(){
	cout << "LDKLTrain [Options] TrainingDataFile [ModelFile]" << endl << endl;
	cout << "Options:"<<endl;
	cout << "-D   : Depth of the LDKL tree."<<endl;
	cout << "-lW  : \\lambdaW = regularizer for classifier parameter W  (try : 0.1, 0.01 or 0.001)."<<endl;
	cout << "-lT  : \\lambdatheta = regularizer for kernel parameter \theta  (try : 0.1, 0.01 or 0.001)."<<endl;
	cout << "-lP  : \\lambdatheta' = regularizer for kernel parameters \theta'  (try : 0.1, 0.01 or 0.001)."<<endl;
	cout << "-S   : \\sigma = parameter for sigmoid sharpness  (try : 1.0, 0.1 or 0.01)."<<endl;
	cout << "-N   : [Optional: default 1] Number of times to train LDKL with different random initializations." << endl;
	cout << "-I   : [Optional: default 15000] Number of passes through the dataset."<<endl;
	cout << "TrainingDataFile : File containing training data."<<endl;
	cout << "ModelFile        : [Optional: default TrainingDataFile.model] Files containing the models learnt by LDKL. For example, given the command LDKLTrain -N 5 ... banana.train, LDKL will learn 5 different models and store them in banana.train.model1, ..., banana.train.model5."<<endl;
	exit(1);
}

int main(int argc, char** argv){
	LDKLModel model;
	if(WINDOWS)
		srand(unsigned(1));
	else
		srand(time(NULL));
	Timer Tm;
	ParseInput(argc,argv,model);
	char buf[1024]; 
	cout << "Running LDKL with following parameters on " << model.DataFile << endl;
	cout << "D : " << log2(unsigned(model.M)) << endl;
	cout << "Sigma : " << model.Sigma << endl;
	cout << "lW : " << model.lW << endl;
	cout << "lThetaPrime : " << model.lThetaPrime << endl;
	cout << "lTheta : " << model.lTheta << endl;
	cout << "NRun : " << model.NRun << endl;
	cout << "MaxIter : " << model.MaxIter << endl;
	cout << "DataFile : " << model.DataFile << endl;
	cout << "ModelFile : " << model.ModelFile << endl;
	cout << "Loading Data"<< endl;
	ReadData(model.DataFile, model.X, model.Y, model.D, model.N);
	cout << "Data Loading done. " << endl;
	for(int i = 0 ; i < model.NRun ; i++){
		cout << "Run : " << i+1 << endl;
		InitModel(model);
		Tm.StartTimer();
		LDKLTrain(model.X, model.Y, model.W, model.Theta, model.ThetaPrime, model.M, model.lW, model.lTheta, model.lThetaPrime, model.Sigma, model.MaxIter, model.N, model.D);
		Tm.StopTimer();
		model.TrainTime[i] = Tm.ElapsedTime();
		cout << "Training Time : "<< model.TrainTime[i] << endl;
		sprintf(buf,"%s%d",model.ModelFile,i+1);
		SaveModel(buf, model);
		delete[] model.W;
		delete[] model.ThetaPrime;
		delete[] model.Theta;
	}
	cout << "Average Training Time : " << avg(model.TrainTime,model.NRun) << endl;
#if SPARSE
	for(int i = 0 ; i < model.N ; i++){
		delete[] model.X[i].idx;
		delete[] model.X[i].val;
	}
#else
	for(int i = 0 ; i < model.N ; i++)
		delete[] model.X[i];
#endif
	delete[] model.X;
	delete [] model.Y;
	delete [] model.TrainTime;
	return 1;
}

void ParseInput(int argc, char** argv,struct LDKLModel &prob){
	if(argc < 12)
		exit_with_help();
	int i;
	prob.Sigma = 0;
	prob.M = 0;
	prob.NRun = 1;
	prob.lTheta = 0;
	prob.lThetaPrime = 0;
	prob.lW = 0;
	prob.MaxIter = 15000;
	for( i = 1 ; i < argc ; i++){
		if(argv[i][0] != '-')
			break;
		if(++i >= argc)
			exit_with_help();
		switch(argv[i-1][1]){
			case 'D':
				prob.M = int(pow(2.0,atoi(argv[i])));
				break;
			case 'S':
				prob.Sigma = (MyFloat)atof(argv[i]);
				break;
			case 'N':
				prob.NRun = atoi(argv[i]);
				break;
			case 'I':
				prob.MaxIter = atoi(argv[i]);
				break;
			case 'l':
				switch(argv[i-1][2]){
					case 'T':
						prob.lTheta = (MyFloat)atof(argv[i]);
						break;
					case 'W':
						prob.lW = (MyFloat)atof(argv[i]);
						break;
					case 'P':
						prob.lThetaPrime = (MyFloat)atof(argv[i]);
						break;
					default:
						cout << "Unknown option: -%c\n"<<argv[i-1][2]<<endl;
						exit_with_help();
						break;
				}
				break;
			default :
				cout << "Unknown option: "<<argv[i-1][1]<<endl;
				exit_with_help();
				break;
		}
	}
	if( i >= argc)
		exit_with_help();
	strcpy(prob.DataFile,argv[i]);
	if(i+1 < argc)
		sprintf(prob.ModelFile,"%s.model",argv[i+1]);
	else{
		char* p = strrchr(argv[i],'/');
		if(p==NULL)
			p = argv[i];
		else
			++p;
		sprintf(prob.ModelFile,"%s.model",p);
	}
	prob.TrainTime = new double[prob.NRun];
}