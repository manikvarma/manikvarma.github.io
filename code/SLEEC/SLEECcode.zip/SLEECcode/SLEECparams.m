params = {};

params.num_learners = 10;
params.num_clusters = 300;
params.num_threads = 32;
params.SVP_neigh = 15;
params.out_Dim = 50;
params.w_thresh = 0.7;
params.sp_thresh = 0.7;
params.cost = 0.1;
params.NNtest = 10;
params.normalize = 1;
params.fname = 'SLEEC';