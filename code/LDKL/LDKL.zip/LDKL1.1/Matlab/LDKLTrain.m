%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use this function for training LDKL model.                             %
% Usage:                                                                 %
% [model] :=LDKLTrain(xTrain, yTrain, D, lW, lT, lP, Sigma,I)            %
%  Input:                                                                %
%      xTrain : DxN training data matrix, where D is data dimension and N%
%               is number of training points.                            %
%      yTrain : Nx1 training label matrix.                               %
%      D      : Depth of the LDKL tree.                                  %
%      lW     : \lambdaW = regularizer for classifier parameter W        %
%               (try : 0.1, 0.01 or 0.001).                              %
%      lT     : \lambdatheta = regularizer for kernel parameter \theta   %
%               (try : 0.1, 0.01 or 0.001).                              %
%      lP     : \lambdatheta' = regularizer for kernel parameters        %
%               \theta' (try : 0.1, 0.01 or 0.001).                      %
%      Sigma  : \sigma = parameter for sigmoid sharpness                 %
%               (try : 1.0, 0.1 or 0.01).                                %
%      I      : [Optional: default 15000] Number of passes through the   %
%               dataset.                                                 %
%  Output:                                                               %
%      model  : Structure containing learnt LDKL model.                  %
%  Author : Suraj Jain                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [model] = LDKLTrain(xTrain, yTrain, D, lW, lT, lP, Sigma,varargin)
if nargin > 8
    error('LDKLTrain:argChk','Function does not take more than 8 inputs.');
elseif nargin < 7
    error('LDKLTrain:argChk','Function does not take less than 7 inputs.');
elseif nargin == 8
    I = varargin{1};
else
    I = 15000;
end    
M = 2^D;
xTrain = [ones(1,size(xTrain,2)); xTrain];
W = randn(2*M - 1, size(xTrain, 1));
ThetaPrime = randn(2*M - 1, size(xTrain, 1));
Theta= randn(M-1, size(xTrain, 1));
if issparse(xTrain)
	[W,Theta,ThetaPrime, trainTime] = mexLDKLTrain(xTrain, single(yTrain), single(Theta'), single(W'), single(ThetaPrime'), single(lW), single(lT), single(lP), single(Sigma),int32(I));
else
	[W,Theta,ThetaPrime, trainTime] = mexLDKLTrain(single(xTrain), single(yTrain), single(Theta'), single(W'), single(ThetaPrime'), single(lW), single(lT), single(lP), single(Sigma),int32(I));
end	
model.Theta = Theta;
model.W = W;
model.ThetaPrime = ThetaPrime;
model.lambdaW = lW;
model.lambdaTheta = lT;
model.lambdaThetaPrime = lP;
model.Sigma = Sigma;
model.trainingTime = trainTime;
end
  

