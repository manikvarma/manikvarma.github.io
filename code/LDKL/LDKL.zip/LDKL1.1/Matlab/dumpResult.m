% Helper file for displaying and saving final results on all the 8 datasets
datasetNames = {'banana';'cifar10binary';'forestNormalized';'IJCNN';'letterbinary';'mnistbinary';'magic04';'usps'};
FinalResult = cell(9,4);
FinalResult{1,1} = 'DatasetName';
FinalResult{1,2} = 'Test Accuracy';
FinalResult{1,3} = 'Test Time';
FinalResult{1,4} = 'Training Time';
for i = 1:length(datasetNames)
    name = datasetNames{i};
    filename = strcat('Result\',name,'\Result.mat');
    load(filename);
    FinalResult{i+1,1} = name;
    FinalResult{i+1,2} = mean(testaccuracy);
    FinalResult{i+1,3} = mean(testtime);
    FinalResult{i+1,4} = mean(trainingtime);
end
clear datasetNames i name filename;
save('FinalResult.mat','FinalResult');
FinalResult
    