%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function classifies data points using the learnt LDKL model.      %
% Usage:                                                                 %
%[Predictiontime Score Accuracy] = LDKLPredict(model,X,y)                %
%       Input:                                                           %
%           model : The LDKL model learnt using LDKLTrain.               %
%           X     : DxN test data matrix, where D is data dimension and N%
%                   is number of data points.                            %
%           y     : Nx1 test label matrix.                               %
%       Output:                                                          %
%           Predictiontime : Time taken to predict class labels.         %
%           Accuracy       : Classification Accuracy.                    %
%           Score          : Value of prediction score.                  %
% Author : Suraj Jain                                                    %  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Predictiontime, Accuracy, Score] = LDKLPredict(model, X, y)
%Append all training points with 1 to take care of b.
X = [ones(1, size(X, 2)); X];
if issparse(X)
    [Correct, Predictiontime, Score] = mexLDKLPredict(X, single(y), single(model.Theta), single(model.W), single(model.ThetaPrime), single(model.Sigma));
else
    [Correct, Predictiontime, Score] = mexLDKLPredict(single(X), single(y), single(model.Theta), single(model.W), single(model.ThetaPrime), single(model.Sigma));
end
Accuracy = double(100.0*Correct)/length(y);
end
