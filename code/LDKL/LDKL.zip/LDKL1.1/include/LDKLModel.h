//////////////////////////////////////////////////////////////////////////////
// This implementation of LDKL was written by Suraj Jain. Please contact    //
// Suraj Jain <sujain@microsoft.com> and Manik Varma <manik@microsoft.com>  //
// for questions or feedback.                                               //
////////////////////////////////////////////////////////////////////////////// 
#ifndef _LDKLMODEL_H_
#define _LDKLMODEL_H_
struct LDKLModel{
	int M,L,D,N,NRun;
	int MaxIter;
	MyFloat lW,lTheta,lThetaPrime,Sigma;
	DATA X;
	LABEL Y;
	MyFloat *W,*ThetaPrime,*Theta;
	double *TrainTime;
	MyFloat *Score;
	char DataFile[1024];
	char ModelFile[1024];
};

void LoadModel(char* filename, struct LDKLModel &model);
void DisplayModel(struct LDKLModel model);
void SaveModel(char *filename, struct LDKLModel model);
void InitModel(struct LDKLModel &model);
#endif