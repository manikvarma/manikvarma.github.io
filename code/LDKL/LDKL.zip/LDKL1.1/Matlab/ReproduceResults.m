%% Run this script for reproducing results reported in ICML 2013 Paper.  %% 
nRun = 1;
runExp('banana.mat', 3, nRun, 0.01, 0.001, 0.001, 1.0)
runExp('letterbinary.mat', 9, nRun, 0.1, 0.01, 0.001, 1.0)
runExp('magic04.mat', 3, nRun, 0.1, 0.001, 0.01, 0.1)
runExp('IJCNN.mat', 3, nRun, 0.01, 0.001, 0.001, 1.0)
runExp('usps.mat', 3, nRun, 0.1, 0.01, 0.01, 0.1)
runExp('forestNormalized.mat', 7, nRun, 0.01, 0.01, 0.001, 1.0)
runExp('mnistbinary.mat', 4, nRun, 0.1, 0.001, 0.01, 0.01)
runExp('cifar10binary.mat', 2, nRun, 1e-2, 1e-1, 1e-1, 2e-3)
dumpResult;