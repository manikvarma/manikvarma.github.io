function runExp(dname, D, NRun, lW, lTheta, lThetaPrime, Sigma)
name  = dname(1:end-4);
load(strcat('./datasets/', dname));
testaccuracy = zeros(NRun, 1);
trainingtime = zeros(NRun, 1);
testtime = zeros(NRun, 1);
if ~exist(strcat('./Result/', name),'dir')
    mkdir(strcat('./Result/', name));
end
if ~exist(strcat('./Models/',name),'dir')
    mkdir(strcat('./Models/',name));
end
disp(name);
for i=1:NRun
    fprintf('Iteration : %d\n',i);
    [model] = LDKLTrain(sparse(xTrain), yTrain, D, lW, lTheta, lThetaPrime, Sigma);
    trainingtime(i) = model.trainingTime;
    [ptime, accuracyTest] = LDKLPredict(model, sparse(xTest), yTest);
    testaccuracy(i) = accuracyTest;
    testtime(i) = ptime;
    save(strcat('./Models/', name, '/', name, '_', num2str(D), '_',num2str(i),'_Model.mat'), 'model');
end
save(strcat('./Result/', name,'/','Result.mat'),'trainingtime','testtime','testaccuracy');
fprintf('Parameters - Depth: %d lamdaW: %f lambdaTheta: %f lambdaThetaPrime: %f Sigma: %f\n', D, lW, lTheta, lThetaPrime, Sigma);
fprintf('%s Training time in mili-seconds  mean: %f  std: %f \n', name,  mean(trainingtime), std(trainingtime));
fprintf('%s Prediction accuracy on test data mean: %f  std: %f\n', name, mean(testaccuracy), std(testaccuracy));
fprintf('%s Prediction time in mili-seconds mean: %f  std: %f \n', name,  mean(testtime), std(testtime));
end

