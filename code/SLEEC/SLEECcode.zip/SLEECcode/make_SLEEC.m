%Make SLEEC
cd SLEEC
make

cd ..

fprintf('SLEEC make complete\n');