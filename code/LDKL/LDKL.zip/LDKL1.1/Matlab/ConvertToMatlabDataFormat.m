%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Run this script to convert datasets from *.train and *.test to *.mat   %
% format used by Matlab version of LDKL code.                            %
% Author : Suraj Jain                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
datasetNames = {'banana';'cifar10binary';'forestNormalized';'IJCNN';...
    'letterbinary';'mnistbinary';'magic04';'usps'};
base = '../datasets/';
for i = 1:length(datasetNames)
    trainfilename = strcat(base,datasetNames{i},'.train');
    testfilename = strcat(base,datasetNames{i},'.test');
    traindata = importdata(trainfilename,' ',1);
    testdata = importdata(testfilename,' ',1);
    xTrain = traindata.data(:,2:end)';
    yTrain = traindata.data(:,1);
    xTest = testdata.data(:,2:end)';
    yTest = testdata.data(:,1);
    save(strcat(base,datasetNames{i},'.mat'),'xTrain','xTest','yTrain','yTest');
    clear traindata testdata trainfilename testfilename xTrain yTrain xTest yTest;
end
clear datasetNames i base;
    
    

